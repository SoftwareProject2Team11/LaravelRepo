<?php $__env->startSection('content'); ?>

<div class="books result">
<h1>Search Books</h1>
<input id="search" placeholder="Title or Author">
<button id="button" type="button">Search</button>
<div id="result"></div>
</div>

<script src="<?php echo e(asset('js/javascriptGoogleBooksApi.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>