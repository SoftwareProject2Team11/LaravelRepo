<?php $__env->startSection('content'); ?>

<h1>Choose one of the following trainings</h1>
<?php if(count($traininglists) > 0): ?>
 <?php $__currentLoopData = $traininglists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traininglist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <a href="/traininglist/<?php echo e($traininglist->trainingId); ?>">
<div class="well">
	<div class="row">
		<div class="col-md-4 col-sm-8">
			<h3>
				<?php echo e($traininglist->trainingName); ?>

			</h3>
			<?php echo $traininglist->trainingSummary; ?>

		</div>
	</div>
</div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php echo e($traininglists->links()); ?> 
<?php else: ?>
<p>No trainings found</p>
<?php endif; ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>