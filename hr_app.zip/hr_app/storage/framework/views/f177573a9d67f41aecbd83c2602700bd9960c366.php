<?php $__env->startSection('content'); ?>
<h1>Choose training for survey</h1>
	<?php

		$user_id = auth()->user()->id;

		$trainings = DB::table('Training_Requests')
		->distinct()
		->where([
			['user_id', '=', $user_id],
			['status', '=', 2],
		])
		->get();

		if(count($trainings) > 0){

			foreach ($trainings as $training) {
				
				$trainingId = $training->trainingId;

				$trainingName = DB::table('Training')
				->select('trainingName')
				->where('trainingId', $trainingId)
				->get();

				$trainingName = substr($trainingName, 18, -3);

				$text = "<a href=" . "/traininglist/{{trainingId}}";

				echo "<a href=" . "/traininglist/{{trainingId}}" . ">
					<div class=" . "well" . ">
						<div class=" . "row" . ">
							<div class=" . "col-md-4 col-sm-8" . ">
								<h3>
									{$trainingName}
								</h3>
							</div>
						</div>
					</div>
				</a>";
			}
		}
		else{
			echo "<p>No trainings found</p>";
		}
	?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>