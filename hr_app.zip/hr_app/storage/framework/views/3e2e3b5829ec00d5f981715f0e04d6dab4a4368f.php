<?php $__env->startSection('content'); ?>

<h1 class="text-center">Survey for <?php echo $trainings->trainingName?></h1>

<div class="row">
            <div class="col-lg-12">

	            <?php
	            	$trainingId = $trainings->trainingId;

	            	$questions = DB::table('Question')
	            	->leftJoin('Answer', 'Question.questionId', '=', 'Answer.questionId')
	            	->select('Question.*')
	            	->where([
	            		['trainingId', '=', $trainingId],
	            		['Answer.userId', '=', null],
	            	])
	            	->get();

/*
	            	$questions = DB::table('Question')
	            	->join('Answer', 'Question.questionId', '=', 'Answer.questionId')
	            	->where([
	            		['trainingId', '=', $trainingId],
	            		['userId', '=', auth()->user()->id],
	            	])
	            	->get();
*/

	            ?>	

	            <?php if(count($questions) > 0): ?>
	            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row">
						<div class="col-md-4 col-sm-8">
							<h3>
								<?php echo e($question->question); ?>

							</h3>


								<?php echo Form::open(['action' => 'surveyListController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


								<div class="form-group">
                    				<!--
									<?php echo e(Form::radio('answer', 'GOOD')); ?>

									<?php echo e(Form::radio('answer', 'BAD')); ?><br>
									-->
									<?php echo e(Form::textArea('answer', '', ['class' => 'form-control', 'placeholder' => 'Write your answer'])); ?>


								</div>

                				<div class="form-group">
                   	 				<?php echo e(Form::hidden('questionId', 'ID of this training')); ?>

                    				<?php echo Form::hidden('questionId', $question->questionId, ['class' => 'form-control', 'readonly']); ?>

               	 				</div>
               	 				<?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>		
                				<?php echo Form::close(); ?>

						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<h3 class="text-center">All questions have been answered</h3>
				<?php endif; ?>
			</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>