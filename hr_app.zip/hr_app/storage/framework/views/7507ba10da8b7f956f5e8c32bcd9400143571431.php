 <?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default panel-custom">
				<div class="panel-heading">Dashboard</div>

				<div class="panel-body">

					<h3>Training Requests</h3>
					<?php if(count($trainingrequests) > 0): ?>
					<table class="table table-striped">
						<tr>
							<th>Training Name</th>
							<th>Requested on</th>
							<th>Approval</th>
							<th></th>
						</tr>
						<?php $__currentLoopData = $trainingrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainingrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>
								<?php
									$trainingId = $trainingrequest->trainingId;

									$trainingName = DB::table('Training')
									->select('trainingName')
									->where('trainingId', $trainingId)
									->get();

									echo substr($trainingName, 18, -3);
								?>
							</td>

							<td><?php echo e($trainingrequest->created_at); ?></td>
							<td>
								<?php
									$statusId = $trainingrequest->status;

									if ($statusId == 1){
										echo "Pending";
									}
									elseif ($statusId == 2) {
										echo "Approved";
									}
									elseif($statusId == 3){
										echo "Refused";
									}
								?>
							</td>
							<td><?php echo Form::open(['action' => ['TrainingRequestsController@destroy', $trainingrequest->requestId], 'method' => 'TRAINING', 'class' => 'pull-right']); ?>

								<?php echo e(Form::hidden('_method', 'DELETE')); ?> <?php echo e(Form::submit('Cancel', ['class' => 'btn btn-danger'])); ?> <?php echo Form::close(); ?>

							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<div class="col-md-12 text-center">
						<a href="/traininglist" class="btn btn-primary">Request a Training</a>
					</div>

					<?php else: ?>
					<p>You have not requested any trainings (yet)!</p>
					<div class="col-md-12 text-center">
						<a href="/traininglist" class="btn btn-primary">Request a Training</a>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>