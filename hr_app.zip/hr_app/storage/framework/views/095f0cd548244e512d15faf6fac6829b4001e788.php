<?php $__env->startSection('content'); ?>

<?php
	$userIsMan = DB::table('users')
	->select('manager')
	->where('id', $userId)
	->get();

	$userIsMan = substr($userIsMan, 12, -2);
?>

<?php if($userIsMan == "0"): ?>
<h1>Fill in the keycode to graduate to manager</h1>

<?php echo Form::open(['action' => 'keyCodeForManController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


    <div class="form-group">
        <?php echo e(Form::label('keyCode', 'Key Code')); ?>

        <?php echo e(Form::text('keyCode', '', ['class' => 'form-control', 'placeholder' => 'Fill in the keyCode'])); ?>

    </div>

    <?php echo e(Form::submit('Enter', ['class' => 'btn btn-primary'])); ?>


<?php echo Form::close(); ?>

<?php else: ?>
<p>You are already a manager</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>