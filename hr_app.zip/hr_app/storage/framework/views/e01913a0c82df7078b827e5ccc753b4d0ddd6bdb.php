<?php $__env->startSection('content'); ?>

<h1>Request a Training</h1>

<?php echo Form::open(['action' => 'TrainingRequestsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    
	<div class="form-group">

        <h3>Write one of the folowing trainings below</h3>
        
        <?php
			$traininglists = DB::table('Training')->get();

			echo '<ul>';
			foreach ($traininglists as $training) {
				$trainingID = $training->trainingId;
				$trainingName = $training->trainingName;
				echo "<li>$trainingID $trainingName</li>";
			}
			echo '</ul>';

			//foreach($traininglists as $traininglist)
			//	echo $traininglist;
			
		?>

        <?php echo e(Form::label('trainingId', 'Training Id')); ?>

        <?php echo e(Form::text('trainingId', '', ['class' => 'form-control', 'placeholder' => 'Write a TrainingId'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('trainingName', 'Training Name')); ?>

        <?php echo e(Form::text('trainingName', '', ['class' => 'form-control', 'placeholder' => 'Write a Training Name'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('reason', 'Reason')); ?>

        <?php echo e(Form::text('reason', '', ['class' => 'form-control', 'placeholder' => 'Write a reason on why you would like to receive this course'])); ?>

    </div>


    <?php echo e(Form::submit('Request', ['class' => 'btn btn-primary'])); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>