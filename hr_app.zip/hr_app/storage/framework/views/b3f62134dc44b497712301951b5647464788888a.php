    <?php $__env->startSection('content'); ?>
       <h1><?php echo $title; ?></h1>
       <p>Software Project 2 Laravel</p>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>