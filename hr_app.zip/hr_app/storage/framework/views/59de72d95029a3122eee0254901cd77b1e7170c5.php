 

<?php $__env->startSection('content'); ?>

<?php
	$userIsMan = DB::table('users')
	->select('manager')
	->where('id', auth()->user()->id)
	->get();

	$userIsMan = substr($userIsMan, 12, -2);
?>

<?php if($userIsMan == "0"): ?>
<p>not authorized for this page</p>

<?php else: ?>
<h1 class="text-center">List of training-requests</h1>
<h3 class="text-center">As manager it is possible to approve requests from employees by clicking on approve</h3>
<br />

<?php $__currentLoopData = $trainingrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainingrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-6">
		<div class="well col-lg-12">
			<div class="row">
				<div class="col-lg-12 text-left">

					<?php
						$trainingId = $trainingrequest->trainingId;

						$trainingName = DB::table('Training')
						->select('trainingName')
						->where('trainingId', $trainingId)
						->get();

						$userId = $trainingrequest->user_id;

						$userName = DB::table('users')
						->select('name')
						->where('id', $userId)
						->get();

						$userMail = DB::table('users')
						->select('email')
						->where('id', $userId)
						->get();

						$currentState = "";

						
						if ($trainingrequest->status == 1){
							$currentState = "Not yet seen";
						}
						elseif ($trainingrequest->status == 2) {
							$currentState = "Approved";
						}
						else{
							$currentState = "Refused";
						}
						
					?>


					<h3>
						<?php echo "Request ID: " . $trainingrequest->requestId ?>
						<br/>
					</h3>
					<h4>	
						<?php echo "Training: " . substr ($trainingName, 18, -3)?>
						<br/>
						<?php echo "User: " . substr($userName, 10, -3) ?>
						<?php echo "(" . substr($userMail, 11, -3) . ")" ?>
						<br />
						<?php echo "Current State: " . $currentState ?>
					</h4>
                    <h5>
                    	Reason to go to this training:
                    </h5>	
                    	
						<?php echo e($trainingrequest->reason); ?>

                    
                        
                        <?php echo Form::open(['action' => ['ManageTrainingsController@update', $trainingrequest->requestId], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


                            <?php echo Form::hidden('requestId', $trainingrequest->requestId, ['class' => 'form-control', 'readonly']); ?>


                            <?php echo e(Form::hidden('_method','PUT')); ?>

                            <?php echo e(Form::submit('Approve', ['class' => 'btn btn-primary'])); ?>


                        <?php echo Form::close(); ?>

                   	<?php if($trainingrequest->status == 2): ?>     
                   	<p>*This training is already approved*</p>     
                    <?php endif; ?>    
				</div>
			</div>
		</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>