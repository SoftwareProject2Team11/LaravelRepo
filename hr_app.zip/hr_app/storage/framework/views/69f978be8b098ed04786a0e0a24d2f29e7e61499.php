<?php $__env->startSection('content'); ?>

<h1>Fill in the keycode to make a new account</h1>

<?php echo Form::open(['action' => 'keyCodeController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


    <div class="form-group">
        <?php echo e(Form::label('keyCode', 'Key Code')); ?>

        <?php echo e(Form::text('keyCode', '', ['class' => 'form-control', 'placeholder' => 'Fill in the keyCode'])); ?>

    </div>

    <?php echo e(Form::submit('Enter', ['class' => 'btn btn-primary'])); ?>


<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>