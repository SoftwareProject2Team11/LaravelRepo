<?php $__env->startSection('content'); ?>

<h1 class="text-center">Choose a Training</h1>
<br>
<?php if(count($trainings) > 0): ?>
 <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
<div class="col-lg-6">
<div class="well col-lg-12">
	<div class="row">
		<div class="col-lg-12">
			<h3>
				<?php
					echo $trainingsId



					//$trainingId = $training->trainingId;

					//$trainingName = DB::table('Training')
					//->select('trainingName')
					//->where('trainingId', $trainingId)
					//->get();

					//echo substr($trainingName, 18, -3);
				?>
			</h3>
		</div>
	</div>
	</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<p>No trainings found</p>
<?php endif; ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>