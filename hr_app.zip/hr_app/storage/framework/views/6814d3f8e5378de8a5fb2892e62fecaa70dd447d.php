 

<?php $__env->startSection('content'); ?>

<?php
	$userIsMan = DB::table('users')
	->select('manager')
	->where('id', auth()->user()->id)
	->get();

	$userIsMan = substr($userIsMan, 12, -2);
?>

    <?php if($userIsMan == "0"): ?>
    <div class="">
    <p>not authorized for this page</p>

    <?php else: ?>
    <h1 class="text-center">Training Requests</h1>
    <h3 class="text-center">Approve or Refuse Training Requests</h3>
</div>


    <br /> 
    <?php $__currentLoopData = $trainingrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainingrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 managerDashboard">
        <div class="panel col-lg-12 trainingRequest">
            <div class="row">
                <div class="col-lg-12 text-left">

                    <?php
						$trainingId = $trainingrequest->trainingId;

						$trainingName = DB::table('Training')
						->select('trainingName')
						->where('trainingId', $trainingId)
						->get();

						$userId = $trainingrequest->user_id;

						$userName = DB::table('users')
						->select('name')
						->where('id', $userId)
						->get();

						$userMail = DB::table('users')
						->select('email')
						->where('id', $userId)
						->get();

						$currentState = "";

						
						if ($trainingrequest->status == 1){
							$currentState = "Not yet seen";
						}
						elseif ($trainingrequest->status == 2) {
							$currentState = "Approved";
						}
						else{
							$currentState = "Refused";
						}
						
					?>


                        <div class="panel-heading
						<?php if($trainingrequest->status == 3) { echo 'refused'; } ?>
		<?php if($trainingrequest->status == 2) { echo 'approved'; } 

		?>
						
						">
                            <h3 class="text-center">
                                <?php echo "Request ID: " . $trainingrequest->requestId ?>
                            </h3>
                        </div>

                        <div class="panel-body">
                            <h4>
                                <?php echo "Training: <b>" . substr ($trainingName, 18, -3) . "</b>"?>
                                <br/>
                                <?php echo "User: <b>" . substr($userName, 10, -3) . "</b>"?>
                                <br>
                                <?php echo "E-Mail: <b>" . substr($userMail, 11, -3) . "</b>"?>
                                <br />
                                <?php echo "Current State: <b>" . $currentState . "</b>"?>
                                <br>
                                Reason:
                            </h4>
                            <p>
                                <?php echo e($trainingrequest->reason); ?>

							</p>
							<br>
							<?php if($trainingrequest->status == 2): ?>
							<p class="text-center">Approved</p>
							<?php elseif($trainingrequest->status ==3): ?>
							<p class="text-center">Refused</p>
							<?php endif; ?>
							




                            <?php if($trainingrequest->status == 1): ?>
                            <div class="row">
                                <div class="col-lg-6 text-center">
                                    <?php echo Form::open(['action' => ['ManageTrainingsController@update', $trainingrequest->requestId], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?> <?php echo Form::hidden('requestId', $trainingrequest->requestId, ['class' => 'form-control', 'readonly']); ?> <?php echo Form::hidden('status', 2, ['class' => 'form-control', 'readonly']); ?> <?php echo e(Form::hidden('_method','PUT')); ?> <?php echo e(Form::submit('Approve', ['class' => 'btn btn-primary btn-approve'])); ?> <?php echo Form::close(); ?>

                                </div>

                                <div class="col-lg-6 text-center">
                                    <?php echo Form::open(['action' => ['ManageTrainingsController@update', $trainingrequest->requestId], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?> <?php echo Form::hidden('requestId', $trainingrequest->requestId, ['class' => 'form-control', 'readonly']); ?> <?php echo Form::hidden('status', 3, ['class' => 'form-control', 'readonly']); ?> <?php echo e(Form::hidden('_method','PUT')); ?> <?php echo e(Form::submit('Refuse', ['class' => 'btn btn-primary btn-refuse'])); ?> <?php echo Form::close(); ?>


                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>