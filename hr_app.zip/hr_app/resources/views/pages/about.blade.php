@extends('layouts.app')

    @section('content')
       <h1><?php echo $title; ?></h1>
       <p>Software Project 2 Laravel</p>
 @endsection